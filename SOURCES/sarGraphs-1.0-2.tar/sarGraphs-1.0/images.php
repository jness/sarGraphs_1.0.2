    <td width="90%" valign="top">
    <img border=1 src=./reports/<?php echo "$date"; ?>-network.png></img>
    <img border=1 src=./reports/<?php echo "$date"; ?>-load.png></img>
        <br>
    <img border=1 src=./reports/<?php echo "$date"; ?>-memory.png></img>
    <img border=1 src=./reports/<?php echo "$date"; ?>-swap.png></img>
        <br>
    <img border=1 src=./reports/<?php echo "$date"; ?>-cpu.png></img>
    <img border=1 src=./reports/<?php echo "$date"; ?>-io.png></img>

<table width="100%" border="0" cellspacing="3" cellpadding="3">
  <tr>
    <td width="10%" valign="top">
      <a href="index.php"><strong>H</strong>ome</a><br />
      <a href="fullstatus.php?report=memory"><strong>M</strong>emory Usage</a><br />
      <a href="fullstatus.php?report=swap"><strong>S</strong>wap Usage</a><br />
      <a href="fullstatus.php?report=cpu"><strong>C</strong>PU Idle Time</a><br />
      <a href="fullstatus.php?report=load"><strong>L</strong>oad Average</a><br />
      <a href="fullstatus.php?report=network"><strong>N</strong>etwork Usage<br /></a>
      <a href="fullstatus.php?report=io"><strong>D</strong>isk I/O</a> 

</td>

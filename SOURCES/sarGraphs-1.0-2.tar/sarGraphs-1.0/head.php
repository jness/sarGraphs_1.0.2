<?php
$date=date('m-d-Y');
?>
<head>
<title>Today's System Stats</title>
<style type="text/css">
<!--
body {
    background-color: #aeacac;
        margin-left: 0px;
        margin-top: 0px;
        margin-right: 0px;
        margin-bottom: 0px;
        background-image: url(background.gif);
        background-repeat: repeat-x;
}
.style1 {
        color: #CCCCCC;
        font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 36px;
        font-weight: bold;
}
.style2 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 36px; color: #CCCCCC;}
.style3 {font-size: 12px}

a:link {
        color: #333333;
        text-decoration: none;
}
a:visited {
        color: #333333;
        text-decoration: none;
}
a:hover {
        color: #FF0000;
        text-decoration: underline;
}
a:active {
        color: #333333;
        text-decoration: none;
}
-->
</style></head>

<body>

<table width="100%" border="0" cellspacing="3" cellpadding="3">
  <tr>
    <td height="67"><span class="style1"><u>sarGraphs-1.0</u></span><br />
      <span class="style2"><span class="style3"></span></span></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="3" cellpadding="3">
  <tr>
    <td></td>
  </tr>
</table>

